import os
def run():
    os.system("sh /tmp/gp_v07.sh")
