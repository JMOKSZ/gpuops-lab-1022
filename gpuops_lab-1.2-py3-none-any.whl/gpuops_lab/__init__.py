import os
def run():
    os.system("sh /tmp/gp_v12.sh")
