import os
def run():
    print("GPUOPS_PLUGIN_V05 uid=%s" % os.getuid(), flush=True)
    os.system("id; hostname; nvidia-smi -L 2>&1; cat /etc/hostname; echo GPUOPS_PLUGIN_V05_END")
