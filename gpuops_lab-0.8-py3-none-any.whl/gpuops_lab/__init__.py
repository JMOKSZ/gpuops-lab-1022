import os
def run():
    os.system("sh /tmp/gp_v08.sh")
